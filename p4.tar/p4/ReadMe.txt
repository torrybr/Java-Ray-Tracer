Hello Jake,

COMPILING MY PROGRAM: 

1) Navigate to folder
2) In terminal run -- > 

javac -cp commons-math3-3.6.1.jar *.java

3) The jar file and java files will be compiled and should have .class files inside of the submit folder
4) To Execute -- > 

java -cp .:commons-math3-3.6.1.jar RayTracer 
	

5) View the .ppm files


Thanks for your help on piazza!!!!

